# 清屏 (QingPing) Android MVP

这是一个 Android Studio Kotlin 项目骨架：展示统计界面、记录由无障碍服务观察到的窗口事件（仅包名/事件类型/时间），提供服务授权引导、开机广播和前台服务配置。它**不是完整广告自动拦截器**；不自动点击、不遮挡其他应用、不绕过应用安全措施。

## 构建
1. 使用 Android Studio（建议最新版）打开此目录。
2. 等待 Gradle 同步。
3. Build > Build APK(s)。
4. APK 通常位于 `app/build/outputs/apk/debug/app-debug.apk`。

Android 需要用户在设置中主动启用无障碍服务。开机恢复及后台运行受厂商策略限制。
