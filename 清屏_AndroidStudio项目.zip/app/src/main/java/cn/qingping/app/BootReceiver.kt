package cn.qingping.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        // Android does not allow this receiver to force-enable accessibility.
        // The app merely records that a boot event was received.
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
            context.getSharedPreferences("qingping", Context.MODE_PRIVATE)
                .edit().putBoolean("boot_seen", true).apply()
        }
    }
}
