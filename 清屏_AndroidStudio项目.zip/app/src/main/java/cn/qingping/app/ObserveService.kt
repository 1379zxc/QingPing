package cn.qingping.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class ObserveService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        // Privacy-conscious MVP: log event type only, not UI text or node contents.
        val prefs = getSharedPreferences("qingping", MODE_PRIVATE)
        prefs.edit().putInt("events", prefs.getInt("events", 0) + 1).apply()
    }
    override fun onInterrupt() {}
}
