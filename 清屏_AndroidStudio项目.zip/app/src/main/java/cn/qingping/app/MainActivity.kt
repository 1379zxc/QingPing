package cn.qingping.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import android.graphics.Typeface

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("qingping", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(32,48,32,32)
        }
        val title = TextView(this).apply { text="清屏"; textSize=30f; setTypeface(null, Typeface.BOLD) }
        val subtitle = TextView(this).apply { text="应用界面事件观察与统计"; textSize=16f }
        val count = TextView(this).apply { textSize=22f; text="已记录事件：${prefs.getInt("events",0)}"; setPadding(0,30,0,30) }
        val status = TextView(this).apply { text="服务状态：请在系统设置中检查无障碍服务"; textSize=14f }
        val enable = Button(this).apply { text="打开无障碍设置"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }
        val refresh = Button(this).apply { text="刷新统计"; setOnClickListener { count.text="已记录事件：${prefs.getInt("events",0)}" } }
        val clear = Button(this).apply { text="清除本地统计"; setOnClickListener {
            prefs.edit().putInt("events",0).apply(); count.text="已记录事件：0"
        } }
        root.addView(title); root.addView(subtitle); root.addView(count); root.addView(status)
        root.addView(enable); root.addView(refresh); root.addView(clear)
        val note=TextView(this).apply {
            text="注意：本版本仅记录窗口变化事件，不读取窗口内容、不自动点击、不保证广告拦截。安卓后台运行受系统及厂商限制。"
            setPadding(0,30,0,0)
        }
        root.addView(note)
        setContentView(root)
    }
}
